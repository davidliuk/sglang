import pathlib,subprocess,json,os,signal,time
root=pathlib.Path('/content/min-tokens');pid=int((root/'worker.pid').read_text());state=pathlib.Path(f'/proc/{pid}/stat')
assert not state.exists() or state.read_text().split()[2]=='Z','Worker still running'
# Stop only a leftover server launched for this experiment, if interrupted in startup.
for proc in pathlib.Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        args=(proc/'cmdline').read_bytes()
        if b'sglang.launch_server' in args and b'/content/min-tokens/model' in args:
            pgid=os.getpgid(int(proc.name));os.killpg(pgid,signal.SIGTERM);print('STOP_LEFTOVER',proc.name)
    except (ProcessLookupError,FileNotFoundError,PermissionError):pass
proto=root/'compiled-prototype';proto.mkdir(exist_ok=True)
for n in ['micro-raw.json','micro-checks.json','gpu-correctness.json','unit.log','micro.log','gpu-correctness.log','e2e.log','e2e-raw.json','e2e-parity.json','worker.log','BENCH_FAILED.json']:
    p=root/n
    if p.exists():p.rename(proto/n)
for p in list(root.glob('*-server.log'))+list(root.glob('*-info.json')):p.rename(proto/p.name)
time.sleep(3)
p=subprocess.Popen(['/content/sglang-env/bin/python',str(root/'worker.py')],stdout=open(root/'worker.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
(root/'worker.pid').write_text(str(p.pid));print('FINAL_WORKER_STARTED',p.pid)
