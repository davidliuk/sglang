import pathlib,subprocess,os,json
r=pathlib.Path('/content/min-tokens');pid=int((r/'worker.pid').read_text());s=pathlib.Path(f'/proc/{pid}/stat')
assert not s.exists() or s.read_text().split()[2]=='Z','Main worker still alive'
assert (r/'BENCH_DONE.json').exists() or (r/'BENCH_FAILED.json').exists(),'No completed worker state'
pathlib.Path('/content/sglang-src/python/sglang/kernels/ops/sampling/min_new_tokens.py').write_bytes((r/'min_new_tokens_kernel.py').read_bytes())
p=subprocess.Popen(['/content/sglang-env/bin/python',str(r/'run-final.py')],stdout=open(r/'postguard-worker.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
(r/'postguard-worker.pid').write_text(str(p.pid));print('FINAL_POSTGUARD_STARTED',p.pid)
