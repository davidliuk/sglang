import pathlib,subprocess,time
r=pathlib.Path('/content/min-tokens');pid=int((r/'postguard-worker.pid').read_text());t=time.monotonic()
while True:
    s=pathlib.Path(f'/proc/{pid}/stat')
    if not s.exists() or s.read_text().split()[2]=='Z':break
    if time.monotonic()-t>900:raise RuntimeError('Final worker did not complete')
    time.sleep(3)
assert (r/'final/DONE.json').exists(),'Final validation failed'
p=subprocess.Popen(['/content/sglang-env/bin/python',str(r/'run-high.py')],stdout=open(r/'high-worker.log','w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(r/'high-worker.pid').write_text(str(p.pid));print('HIGH_STARTED',p.pid)
