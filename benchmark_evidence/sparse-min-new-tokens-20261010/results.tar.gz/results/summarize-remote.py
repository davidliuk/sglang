import pathlib,json,statistics,collections
r=pathlib.Path('/content/min-tokens')
p=r/'micro-raw.json'
if p.exists():
    groups=collections.defaultdict(lambda:collections.defaultdict(list))
    for x in json.loads(p.read_text()):groups[(x['batch'],x['vocab'],x['stops'])][x['variant']].append(x['gpu_us'])
    for key,vals in groups.items():
        if key[1]==151936 and key[2]==1 and set(vals)=={'baseline','pr'}:
            a=statistics.median(vals['baseline']);b=statistics.median(vals['pr']);print('micro',key,{'baseline_us':a,'pr_us':b,'speedup':a/b})
p=r/'e2e-raw.json'
if p.exists():
    groups=collections.defaultdict(lambda:collections.defaultdict(list))
    for x in json.loads(p.read_text()):groups[(x['mode'],x['case'],x['cached'],x['stream'])][x['variant']].append(x['tokens_s'])
    for key,vals in groups.items():
        if set(vals)=={'baseline','pr'}:
            a=statistics.median(vals['baseline']);b=statistics.median(vals['pr']);print('e2e',key,{'baseline_tokens_s':a,'pr_tokens_s':b,'change_pct':(b/a-1)*100,'samples':{k:len(v) for k,v in vals.items()}})
