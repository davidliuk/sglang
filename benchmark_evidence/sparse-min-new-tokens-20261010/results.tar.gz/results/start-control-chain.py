import pathlib,subprocess
r=pathlib.Path('/content/min-tokens')
p=subprocess.Popen(['/content/sglang-env/bin/python',str(r/'chain-control.py')],stdout=open(r/'chain-control.log','w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(r/'chain-control.pid').write_text(str(p.pid));print('CONTROL_CHAIN_STARTED',p.pid)
