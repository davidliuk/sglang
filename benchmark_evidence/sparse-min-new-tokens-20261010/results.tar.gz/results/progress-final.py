import pathlib,json
r=pathlib.Path('/content/min-tokens')
for name in ['chain-final.log','postguard-worker.log','final-tests.log','final/e2e.log','final/DONE.json','final/FAILED.json']:
    p=r/name
    if p.exists():print(name,p.read_text()[-4000:])
for name in ['final/e2e-raw.json','final/natural-raw.json']:
    p=r/name
    if p.exists():
        rows=json.loads(p.read_text());print(name,len(rows),{k:v for k,v in rows[-1].items() if k not in ['outputs','response','request']})
