import pathlib,os,signal,time
r=pathlib.Path('/content/min-tokens');pid=int((r/'worker.pid').read_text())
children=pathlib.Path(f'/proc/{pid}/task/{pid}/children')
for child in children.read_text().split() if children.exists() else []:
    cmd=pathlib.Path(f'/proc/{child}/cmdline').read_bytes()
    if b'/content/min-tokens/e2e.py' in cmd:
        os.kill(int(child),signal.SIGINT);print('SIGINT_E2E',child)
