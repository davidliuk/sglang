import pathlib,subprocess,json
root=pathlib.Path('/content/min-tokens');pid=int((root/'worker.pid').read_text());state=pathlib.Path(f'/proc/{pid}/stat')
assert not state.exists() or state.read_text().split()[2]=='Z','Worker still running'
for n in ['micro.log','worker.log','BENCH_FAILED.json']:
    p=root/n
    if p.exists():p.rename(root/('attempt3-'+n))
p=subprocess.Popen(['/content/sglang-env/bin/python',str(root/'worker.py')],stdout=open(root/'worker.log','w'),stderr=subprocess.STDOUT,start_new_session=True)
(root/'worker.pid').write_text(str(p.pid));print('WORKER_STARTED',p.pid)
