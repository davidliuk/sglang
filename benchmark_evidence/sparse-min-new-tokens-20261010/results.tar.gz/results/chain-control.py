import pathlib,subprocess,time
r=pathlib.Path('/content/min-tokens');pid=int((r/'high-worker.pid').read_text());t=time.monotonic()
while True:
    s=pathlib.Path(f'/proc/{pid}/stat')
    if not s.exists() or s.read_text().split()[2]=='Z':break
    if time.monotonic()-t>900:raise RuntimeError('High worker did not finish')
    time.sleep(3)
assert (r/'high/DONE.json').exists(),'High run failed'
p=subprocess.Popen(['/content/sglang-env/bin/python',str(r/'control.py')],stdout=open(r/'control-worker.log','w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(r/'control-worker.pid').write_text(str(p.pid));print('CONTROL_STARTED',p.pid)
