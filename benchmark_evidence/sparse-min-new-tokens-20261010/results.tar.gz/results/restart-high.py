import pathlib,subprocess
r=pathlib.Path('/content/min-tokens');pid=int((r/'high-worker.pid').read_text());s=pathlib.Path(f'/proc/{pid}/stat')
assert not s.exists() or s.read_text().split()[2]=='Z','Prior high worker still alive'
assert (r/'high/FAILED.json').exists(),'No failed high run to resume'
(r/'high').rename(r/'high-cache-attempt')
p=subprocess.Popen(['/content/sglang-env/bin/python',str(r/'run-high.py')],stdout=open(r/'high-worker.log','w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(r/'high-worker.pid').write_text(str(p.pid));print('HIGH_RESTARTED',p.pid)
