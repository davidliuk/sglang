import pathlib,subprocess
r=pathlib.Path('/content/min-tokens')
p=subprocess.Popen(['/content/sglang-env/bin/python',str(r/'chain-high.py')],stdout=open(r/'chain-high.log','w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(r/'chain-high.pid').write_text(str(p.pid));print('HIGH_CHAIN_STARTED',p.pid)
