import pathlib,subprocess
r=pathlib.Path('/content/min-tokens')
p=subprocess.Popen(['/content/sglang-env/bin/python','/content/min-tokens-next/chain-final.py'],stdout=open(r/'chain-final.log','w'),stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(r/'chain-final.pid').write_text(str(p.pid));print('CHAIN_STARTED',p.pid)
