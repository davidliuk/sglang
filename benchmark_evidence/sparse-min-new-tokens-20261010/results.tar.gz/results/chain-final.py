import pathlib,subprocess,os,time,json,shutil
r=pathlib.Path('/content/min-tokens');n=pathlib.Path('/content/min-tokens-next')
pid=int((r/'worker.pid').read_text());began=time.monotonic()
while True:
    state=pathlib.Path(f'/proc/{pid}/stat')
    if not state.exists() or state.read_text().split()[2]=='Z':break
    if time.monotonic()-began>900:raise RuntimeError('Prior worker did not finish')
    time.sleep(3)
assert (r/'BENCH_DONE.json').exists() or (r/'BENCH_FAILED.json').exists()
for old,new in [('pr_min_new_tokens.py','pre_guard_min_new_tokens.py'),('min_new_tokens_kernel.py','pre_guard_kernel.py'),('micro-raw.json','pre_guard_micro-raw.json'),('micro-checks.json','pre_guard_micro-checks.json'),('test_penaltylib.py','pre_guard_test_penaltylib.py')]:
    if (r/old).exists():shutil.copy2(r/old,r/new)
for p in n.iterdir():
    if p.is_file():shutil.copy2(p,r/p.name)
subprocess.run(['/content/sglang-env/bin/python',str(r/'start-postguard.py')],check=True)
