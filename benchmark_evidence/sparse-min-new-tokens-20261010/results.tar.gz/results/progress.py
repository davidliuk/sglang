import pathlib,json,os
r=pathlib.Path('/content/min-tokens')
for n in ['BENCH_DONE.json','BENCH_FAILED.json','worker.pid']:
    p=r/n
    if p.exists():print(n,p.read_text())
for n in ['worker.log','unit.log','micro.log','e2e.log']:
    p=r/n
    if p.exists():print(n,p.read_text()[-7000:])
for p in r.glob('*-server.log'):
    print(p.name,p.read_text()[-2500:])
for n in ['micro-raw.json','e2e-raw.json']:
    p=r/n
    if p.exists():
        data=json.loads(p.read_text());print(n,'samples',len(data),'last',{k:v for k,v in data[-1].items() if k!='outputs'})
