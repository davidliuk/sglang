import subprocess,pathlib,os,time,json,sys
root=pathlib.Path('/content/min-tokens');python='/content/sglang-env/bin/python'
env={**os.environ,'PATH':'/content/sglang-env/bin:'+os.environ.get('PATH',''),'PYTHONPATH':'/content/sglang-src/python','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
started=time.monotonic();timings={}
def run(name,args):
    t=time.monotonic();print('START',name,flush=True)
    with open(root/(name+'.log'),'w') as log:subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    timings[name]=time.monotonic()-t;print('DONE',name,timings[name],flush=True)
try:
    pathlib.Path('/content/sglang-src/python/sglang/srt/sampling/penaltylib/min_new_tokens.py').write_bytes((root/'pr_min_new_tokens.py').read_bytes())
    run('unit',[python,'-m','pytest',str(root/'test_penaltylib.py'),'-q'])
    run('kernel-tests',[python,'-m','pytest',str(root/'test_min_new_tokens.py'),'-q'])
    run('micro',[python,str(root/'bench.py')])
    run('gpu-correctness',[python,str(root/'gpu-correctness.py')])
    run('e2e',[python,str(root/'e2e.py')])
    run('final-tests',[python,str(root/'final-tests.py')])
    timings['total']=time.monotonic()-started;(root/'BENCH_DONE.json').write_text(json.dumps(timings,indent=2))
except BaseException as e:
    (root/'BENCH_FAILED.json').write_text(json.dumps({'error':repr(e),'timings':timings}));raise
